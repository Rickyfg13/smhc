<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Code_model extends MY_Model {

    

}

/* End of file Code_model.php */
