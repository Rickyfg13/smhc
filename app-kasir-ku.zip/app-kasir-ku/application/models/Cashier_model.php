<?php


defined('BASEPATH') or exit('No direct script access allowed');

class Cashier_model extends MY_Model
{

    public $table = 'transaction';
    public $perPage = 8;
}

/* End of file Cashier_model.php */
