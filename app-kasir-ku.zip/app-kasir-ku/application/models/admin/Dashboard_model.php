<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends MY_Model {

    public $table = 'transaction';

    public function setSession()
    {
        
    }

}

/* End of file Dashboard_model.php */
