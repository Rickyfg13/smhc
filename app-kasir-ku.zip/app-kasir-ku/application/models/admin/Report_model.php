<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Report_model extends MY_Model {

    public $table = 'transaction';

}

/* End of file Report_model.php */
