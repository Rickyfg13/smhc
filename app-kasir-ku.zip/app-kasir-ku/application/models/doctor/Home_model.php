<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends MY_Model {

    public $table   = 'doctor';
    public $perPage = 10;

}

/* End of file Home_model.php */
